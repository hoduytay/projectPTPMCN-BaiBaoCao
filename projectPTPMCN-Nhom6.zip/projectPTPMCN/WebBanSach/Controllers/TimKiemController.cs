﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanSach.Models;
using PagedList.Mvc;
using PagedList;

namespace WebBanSach.Controllers
{
    public class TimKiemController : Controller
    {
        // GET: TimKiem
        QuanLyBanSachModel db = new QuanLyBanSachModel();
        [HttpPost]
        public ActionResult KetQuaTimKiem(FormCollection f,int? page)
        {
            string sTuKhoa = f["txtTimKiem"].ToString();
            List<Sach> lstKQTK = db.Saches.Where(n => n.TenSach.Contains(sTuKhoa)).ToList();
            int pageNumber = (page ?? 1);
            int pageSize = 9;
            if (lstKQTK.Count == 0)
            {
                ViewBag.ThongBao1 = "Không tìm thấy tên Sách tương ứng";

            }
            ViewBag.ThongBao2 = "Đã tìm thấy " + lstKQTK.Count + " Cuốn Sách";
            ViewBag.ThongBao3 = sTuKhoa;
            
            
            return View(lstKQTK.OrderBy(n=>n.TenSach).ToPagedList(pageNumber,pageSize));
        }
    }
}