﻿namespace WebBanSach.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("KhachHang")]
    public partial class KhachHang
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public KhachHang()
        {
            DonHangs = new HashSet<DonHang>();
        }

        [Key]
        public int MaKH { get; set; }
        [Display(Name = "Họ Tên" )]
        [StringLength(50)]
        public string HoTen { get; set; }
        [Display(Name = "Tài Khoản")]
        [StringLength(50)]
        public string TaiKhoan { get; set; }
        [Display(Name = "Mật Khẩu")]
        [StringLength(50)]
        public string MatKhau { get; set; }
        [Display(Name = "Email")]
        [StringLength(100)]
        public string Email { get; set; }
        [Display(Name = "Địa Chỉ")]
        [StringLength(100)]
        public string DiaChi { get; set; }
        [Display(Name = "Điện Thoại")]
        [StringLength(50)]
        public string DienThoai { get; set; }
        [Display(Name = "Giới Tính")]
        [StringLength(50)]
        public string GioiTinh { get; set; }
        [Display(Name = "Ngày Sinh")]
        public DateTime? NgaySinh { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<DonHang> DonHangs { get; set; }
    }
}
